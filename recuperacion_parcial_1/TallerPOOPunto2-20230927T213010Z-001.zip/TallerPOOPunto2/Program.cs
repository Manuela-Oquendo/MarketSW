﻿
using TallerPOOPunto2;

class Program
{
    static void Main(string[] args)
    {
        // Crear una instancia de un curso (por ejemplo)
        Curso cursoIngles = new Curso("Inglés Básico", "Gramática, vocabulario, conversación", "30", "Básico", DateTime.Now, DateTime.Now.AddMonths(3), 200, 1000);
        Curso cursoFrances = new Curso("Inglés Básico", "Gramática, vocabulario, conversación", "30", "Básico", DateTime.Now, DateTime.Now.AddMonths(3), 200, 1000);
        Curso cursoPortugues = new Curso("Inglés Básico", "Gramática, vocabulario, conversación", "30", "Básico", DateTime.Now, DateTime.Now.AddMonths(3), 200, 1000);
        // Crear una instancia de un alumno (por ejemplo)
        Alumno alumno = new Alumno(123456789, "Pérez", "Juan", "Calle Principal 123", "123456789", "Estudiante", cursoIngles, "Tarjeta de Crédito", 3);

        while (true)
        {
            Console.WriteLine("Menú:");
            Console.WriteLine("1. Mostrar información del curso");
            Console.WriteLine("2.Agregar alumno a curso");
            Console.WriteLine("3. Mostrar información del alumno");
            Console.WriteLine("4. Salir");
            Console.Write("Elija una opción: ");

            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Console.WriteLine("\nInformación del Curso:");
                    Console.WriteLine(cursoIngles.ToString());
                    break;
                
                    case "2":
                    Console.WriteLine("Seleccione a que curso se va a matricular");
                    int op = int.Parse(Console.ReadLine());
                    if (op == 1) {

                        cursoIngles.AgregarAlumno(alumno);
                        alumno.AsignarCurso(cursoIngles);

                    } else if (op==2) {

                        cursoFrances.AgregarAlumno(alumno);
                        alumno.AsignarCurso(cursoFrances);
                    } else if(op==3){
                        cursoPortugues.AgregarAlumno(alumno);
                        alumno.AsignarCurso(cursoPortugues);
                    }
                    

                    break;
                case "3":
                    Console.WriteLine("\nInformación del Alumno:");
                    Console.WriteLine(alumno.ToString());
                    break;

                case "4":
                    return;

                default:
                    Console.WriteLine("Opción no válida. Intente de nuevo.");
                    break;
            }

            Console.WriteLine("\nPresione Enter para continuar...");
            Console.ReadLine();
            Console.Clear();
        }
    }
}
