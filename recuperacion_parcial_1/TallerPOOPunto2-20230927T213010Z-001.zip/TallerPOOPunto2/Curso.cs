﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TallerPOOPunto2
{
    public class Curso
    {
        public string Nombre { get; set; }
        public string Contenido { get; set; }
        public string Duracion { get; set; }
        public string Nivel { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public decimal Matricula { get; set; }
        public decimal Precio { get; set; }

        public Curso(string nombre, string contenido, string duracion, string nivel, DateTime fechaInicio, DateTime fechaFin, decimal matricula, decimal precio)
        {
            Nombre = nombre;
            Contenido = contenido;
            Duracion = duracion;
            Nivel = nivel;
            FechaInicio = fechaInicio;
            FechaFin = fechaFin;
            Matricula = matricula;
            Precio = precio;
        }

        private List<Alumno> alumnosInscritos = new List<Alumno>();

        public void AgregarAlumno(Alumno alumno)
        {
            alumnosInscritos.Add(alumno);
        }
        public override string ToString()
        {
            return $"Curso: {Nombre}\nContenido: {Contenido}\nDuración: {Duracion} horas\nNivel: {Nivel}\nFecha de inicio: {FechaInicio.ToShortDateString()}\nFecha de fin: {FechaFin.ToShortDateString()}\nMatrícula: {Matricula:C}\nPrecio: {Precio:C}";
        }
    }

}
