﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TallerPOOPunto2
{
    public class Alumno
    {
        public int Cedula { get; set; }
        public string Apellido { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public string Ocupacion { get; set; }
        public Curso CursoInscrito { get; set; }
        public string FormaPago { get; set; }
        public int PlanPago { get; set; }

        public Alumno(int cedula, string apellido, string nombre, string direccion, string telefono, string ocupacion, Curso cursoInscrito, string formaPago, int planPago)
        {
            Cedula = cedula;
            Apellido = apellido;
            Nombre = nombre;
            Direccion = direccion;
            Telefono = telefono;
            Ocupacion = ocupacion;
            CursoInscrito = cursoInscrito;
            FormaPago = formaPago;
            PlanPago = planPago;
        }


        public void AsignarCurso(Curso curso)
        {
            CursoInscrito = curso;
        }
        public override string ToString()
        {
            return $"Alumno: {Nombre} {Apellido}\nCédula: {Cedula}\nDirección: {Direccion}\nTeléfono: {Telefono}\nOcupación: {Ocupacion}\nCurso Inscrito: {CursoInscrito.Nombre}\nForma de Pago: {FormaPago}\nPlan de Pago: {PlanPago} cuotas";
        }
    }
}
